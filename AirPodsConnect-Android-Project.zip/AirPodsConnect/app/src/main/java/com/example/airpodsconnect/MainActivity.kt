package com.example.airpodsconnect

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 42
    private lateinit var status: TextView
    private lateinit var connectButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt()
        window.navigationBarColor = 0xFF000000.toInt()
        buildScreen()
        refreshBluetoothStatus()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(0xFF000000.toInt())
        }

        val top = TextView(this).apply {
            text = "AirPods Connect"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(top, matchWrap())

        val subtitle = TextView(this).apply {
            text = "ПОДКЛЮЧЕНИЕ И УПРАВЛЕНИЕ"
            textSize = 10f
            letterSpacing = 0.18f
            setTextColor(0xFF888888.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(30))
        }
        page.addView(subtitle, matchWrap())

        val hero = TextView(this).apply {
            text = "◖  ))"
            textSize = 64f
            setTextColor(0xFFEDEDED.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(22))
        }
        page.addView(hero, matchWrap())

        status = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        }
        page.addView(status, matchWrap())

        connectButton = Button(this).apply {
            text = "Подключить AirPods"
            isAllCaps = false
            textSize = 16f
            setTextColor(0xFF000000.toInt())
            setBackgroundColor(0xFFFFFFFF.toInt())
            setOnClickListener { openBluetoothSettings() }
        }
        page.addView(connectButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        ))

        val section = TextView(this).apply {
            text = "СОСТОЯНИЕ ЗАРЯДА"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(0xFF888888.toInt())
            setPadding(0, dp(34), 0, dp(12))
        }
        page.addView(section, matchWrap())

        val batteryCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(0xFF171717.toInt())
        }
        addBatteryRow(batteryCard, "Левый наушник", "—")
        addDivider(batteryCard)
        addBatteryRow(batteryCard, "Правый наушник", "—")
        addDivider(batteryCard)
        addBatteryRow(batteryCard, "Зарядный кейс", "—")
        page.addView(batteryCard, matchWrap())

        val note = TextView(this).apply {
            text = "Уровень заряда появится, если Android передаст его от вашей модели AirPods. Приложение не показывает выдуманные проценты."
            textSize = 12f
            setTextColor(0xFF777777.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(18), dp(8), 0)
        }
        page.addView(note, matchWrap())

        val settings = TextView(this).apply {
            text = "Настройки Bluetooth  ›"
            textSize = 14f
            setTextColor(0xFFBBBBBB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(8))
            setOnClickListener { openBluetoothSettings() }
        }
        page.addView(settings, matchWrap())

        setContentView(page)
    }

    private fun addBatteryRow(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        val name = TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(0xFFEAEAEA.toInt())
        }
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        val amount = TextView(this).apply {
            text = value
            textSize = 14f
            setTextColor(0xFF999999.toInt())
        }
        row.addView(amount)
        parent.addView(row, matchWrap())
    }

    private fun addDivider(parent: LinearLayout) {
        parent.addView(View(this).apply {
            setBackgroundColor(0xFF303030.toInt())
        }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun refreshBluetoothStatus() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        val enabled = try { adapter?.isEnabled == true } catch (_: SecurityException) { false }
        status.text = if (enabled) "Bluetooth включён" else "Bluetooth выключен"
    }

    private fun openBluetoothSettings() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), requestCode)
            return
        }
        try {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openBluetoothSettings()
            } else {
                Toast.makeText(this, "Разрешение Bluetooth необходимо для проверки состояния.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
