# AirPods Connect

A small Android Studio starter project with a black, Apple-inspired interface.

## What works in this starter
- Opens Android Bluetooth settings so the user can pair AirPods through the system.
- Displays whether Bluetooth is enabled.
- Uses a black interface with dark cards and white text.
- Does not invent battery percentages.

## Important limitations
Android does not provide a universal public API for reading the separate left/right AirPods and case battery levels. Availability depends on the AirPods model and Android firmware. This starter therefore shows placeholders instead of fake values. Pairing itself is performed by Android's Bluetooth settings.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Language: Kotlin
